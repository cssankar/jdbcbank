package com.cg.plp.bean;

public class TransactionDetails {
	private double credit;
	private double debit;
	private int accountNumber;
	private double accountBalance;
	public double getCredit() {
		return credit;
	}
	public void setCredit(double credit) {
		this.credit = credit;
	}
	public double getDebit() {
		return debit;
	}
	public void setDebit(double debit) {
		this.debit = debit;
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
//	public TransactionDetails(double credit, double debit, int accountNumber, double accountBalance) {
//		super();
//		this.credit = credit;
//		this.debit = debit;
//		this.accountNumber = accountNumber;
//		this.accountBalance = accountBalance;
//	}
	@Override
	public String toString() {
		return "TransactionDetails [credit=" + credit + ", debit=" + debit + ", accountNumber=" + accountNumber
				+ ", accountBalance=" + accountBalance + "]";
	}
	
}
