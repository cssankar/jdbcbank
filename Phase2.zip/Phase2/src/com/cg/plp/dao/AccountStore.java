package com.cg.plp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.plp.bean.AccountDetails;

public class AccountStore {
	public Connection getConnection() {
        Connection con=null;
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "system");
                    } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return con;
    }

 

	public double displayBalance(int accountNumber) throws SQLException {
		 double balance=0;
	       
	            Connection con = getConnection();
	            PreparedStatement stmt = con.prepareStatement("select accountBalance from accountdetails where accountnumber=?");
	            stmt.setInt(1, accountNumber);
	            ResultSet rs=stmt.executeQuery();
	            while(rs.next()) {
	                balance=rs.getDouble("accountBalance");
	            }
	            
	       
	        return balance;
	    }

	 
	
	
	public void depositAmount(int accountNumber,double credit) throws SQLException {
	    double amount=0;
        
            Connection con = getConnection();
            PreparedStatement stmt = con.prepareStatement("update accountdetails set accountBalance=? where accountnumber=?");
            amount=displayBalance(accountNumber)+credit;
            stmt.setDouble(1,amount);
            stmt.setInt(2, accountNumber);
            stmt.executeUpdate();
            PreparedStatement stmt2 = con.prepareStatement("insert into transactiondetails values(?,?,?,?)");
            stmt2.setInt(1,accountNumber);
            stmt2.setDouble(2,amount);
            stmt2.setDouble(3, credit);
            stmt2.setDouble(4,0);
            stmt2.executeUpdate();
           
	}
	public void accountCreation(AccountDetails details) throws SQLException {
		 
	            Connection con = getConnection();
	            PreparedStatement stmt = con.prepareStatement("insert into accountdetails values(?,?,?)");
	            stmt.setInt(1,details.getAccountNumber());
	            stmt.setDouble(2, details.getAccountBalance());
	            stmt.setString(3, details.getAccountHolderName());
	            
	            stmt.executeUpdate();
	            PreparedStatement stmt2 = con.prepareStatement("insert into transactiondetails values(?,?,?,?)");
	            stmt2.setInt(1,details.getAccountNumber());
	            stmt2.setDouble(2,details.getAccountBalance());
	            stmt2.setDouble(3, 0);
	            stmt2.setDouble(4, details.getAccountBalance());
	            stmt2.executeUpdate();
	           
       
	}
	
	public void withdrawAmount(int accountNumber, double debit) throws SQLException {
		 double amount=0;
	        
	            Connection con = getConnection();
	            PreparedStatement stmt = con.prepareStatement("update accountdetails set accountBalance=? where accountnumber=?");
	            amount= displayBalance(accountNumber)-debit;
	            stmt.setDouble(1, amount);
	            stmt.setInt(2, accountNumber);
	            stmt.executeUpdate();
	            PreparedStatement stmt2 = con.prepareStatement("insert into transactiondetails values(?,?,?,?)");
	            stmt2.setInt(1,accountNumber);
	            stmt2.setDouble(2,amount);
	            stmt2.setDouble(3, 0);
	            stmt2.setDouble(4, debit);
	            stmt2.executeUpdate();

	       
	}
	public ResultSet showTransactions(int accountNumber) throws SQLException {
		  ResultSet rs=null;
	        
	            Connection con = getConnection();
	            PreparedStatement stmt = con.prepareStatement("select * from transactiondetails where accountnumber=?");
	            stmt.setInt(1, accountNumber);
	            rs=stmt.executeQuery();
	           
	        return rs;
	    }
	}

