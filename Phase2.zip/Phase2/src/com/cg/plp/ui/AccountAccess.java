package com.cg.plp.ui;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import java.util.Scanner;

import com.cg.plp.bean.AccountDetails;
import com.cg.plp.bean.TransactionDetails;
import com.cg.plp.ser.AccountOperations;
import com.cg.plp.ser.AccountProcess;

public class AccountAccess {
	static Scanner scan = new Scanner(System.in);
	static AccountOperations operate = new AccountProcess();
	static TransactionDetails transactionDetails = new TransactionDetails();

	public static void main(String[] args) {
		int accountNumber;
		String accountHolderName;
		double accountBalance;
		double credit;
		double debit;

		for (;;) {

			System.out.println("1. Create Account");
			System.out.println("2. Show Balance");
			System.out.println("3. Deposit Cash");
			System.out.println("4. Withdraw Cash");
			System.out.println("5. Fund Transfer");
			System.out.println("6. Mini Statement");
			System.out.println("Enter Your Choice:");
			int n = scan.nextInt();
			switch (n) {
			case 1: {
				AccountDetails accountDetails = new AccountDetails();
				System.out.print("Enter your Name: ");
				accountDetails.setAccountHolderName(scan.next());
				accountDetails.setAccountNumber((int) (Math.random() * 1000));
				System.out.println("Your Account Number is: " + accountDetails.getAccountNumber());
				System.out.print("Enter your first Deposit: ");
				accountDetails.setAccountBalance(scan.nextDouble());
				operate.createAccount(accountDetails);

			}
				break;
			case 2: {
				System.out.print("Enter Your Account Number: ");
				accountNumber = scan.nextInt();
				try {
					System.out.println("Your Account Balance is: " + operate.showBalance(accountNumber));
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
				break;
			case 3: {
				System.out.print("Enter Your Account Number: ");
				accountNumber = scan.nextInt();
				System.out.print("Enter the amount you want to deposit: ");
				credit = scan.nextInt();
				try {
					operate.deposit(accountNumber, credit);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
				break;
			case 4: {
				System.out.print("Enter Account Number: ");
				accountNumber = scan.nextInt();
				System.out.print("Enter the amount you want to withdraw: ");
				debit = scan.nextInt();
				System.out.println("Balance debited from account: " + accountNumber + "\nDebited: " + debit
						+ "\nAvailable balance is: ");
				try {
					operate.withdraw(accountNumber, debit);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
				break;
			case 5: {
				System.out.print("Enter Your Account Number: ");
				int senderAccountNumber = scan.nextInt();
				System.out.print("Enter Receiver Account Number: ");
				int receiverAccountNumber = scan.nextInt();
				System.out.print("Enter the amount you want to transfer: ");
				double transferAmount = scan.nextInt();

			}
				break;
			case 6: {
				System.out.print("Enter Account Number: ");
				accountNumber = scan.nextInt();
				ResultSet resultSet = null;
				try {
					resultSet = operate.getTransactionDetails(accountNumber);

					System.out.println("Transaction List: ");

					while (resultSet.next()) {
					System.out.println(resultSet.getInt("accountNumber"));	
					System.out.println(resultSet.getDouble("accountBalance"));
					System.out.println(resultSet.getDouble("credit"));
					System.out.println(resultSet.getDouble("debit"));
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
				break;
			case 7:
				System.out.println("Exited....");
				scan.close();
				System.exit(0);
				break;

			default:
				System.out.println("Invalid Choice..Try again");
				break;
			}
		}

	}

}
